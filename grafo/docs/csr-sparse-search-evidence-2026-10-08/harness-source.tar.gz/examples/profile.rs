//! Owned, bounded profiling loop; sample the main thread after READY.
use grafo_csr_investigation::Fixture;
use grafo_probe::{Policy, Scratch};
use std::hint::black_box;
use std::time::{Duration, Instant};

fn main() {
    let mode = std::env::args().nth(1).unwrap_or_else(|| "native".into());
    let seconds: u64 = std::env::args()
        .nth(2)
        .and_then(|s| s.parse().ok())
        .unwrap_or(10);
    let fixture = Fixture::sparse(100_000, 4);
    let mut raw = fixture.edges.clone();
    raw.sort_unstable_by_key(|&(a, b, _)| (a, b));
    let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
    let edges: Vec<_> = raw
        .iter()
        .map(|&(a, b, w)| {
            (
                fixture.labels[a as usize].as_str(),
                fixture.labels[b as usize].as_str(),
                w,
            )
        })
        .collect();
    let real = grafo::Graph::new(&nodes, &edges).unwrap();
    let probe = grafo_probe::Graph::new(&nodes, &edges).unwrap();
    let mut scratch = Scratch::default();
    let mut retained = vec![f64::INFINITY; 100_000];
    assert_eq!(
        probe
            .probe_search("0", "99999", Policy::ReuseEpoch, &mut scratch)
            .unwrap(),
        Some(116.0)
    );
    println!("READY mode={mode} pid={}", std::process::id());
    let started = Instant::now();
    let mut calls = 0_u64;
    while started.elapsed() < Duration::from_secs(seconds) {
        for _ in 0..4096 {
            match mode.as_str() {
                "native" => {
                    black_box(
                        real.shortest_path_cost(black_box("0"), black_box("99999"))
                            .unwrap(),
                    );
                }
                "epoch" => {
                    black_box(
                        probe
                            .probe_search(
                                black_box("0"),
                                black_box("99999"),
                                Policy::ReuseEpoch,
                                &mut scratch,
                            )
                            .unwrap(),
                    );
                }
                "fill" => {
                    black_box(retained.as_mut_slice()).fill(black_box(f64::INFINITY));
                }
                _ => panic!("unknown profile mode"),
            }
        }
        calls += 4096;
    }
    println!("DONE calls={calls} elapsed={:?}", started.elapsed());
}
