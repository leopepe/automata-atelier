//! Untimed search-work/allocation counters; do not use this binary for timings.
use grafo_csr_investigation::{Fixture, fixtures, stock_cost};
use grafo_probe::{Policy, Scratch};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed};

struct CountingAllocator;
static ENABLED: AtomicBool = AtomicBool::new(false);
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
static REALLOCS: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);

// SAFETY: all operations delegate unchanged pointers/layouts to System. Atomic counters
// neither dereference allocations nor alter allocator ownership, alignment or lifetimes.
unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        if ENABLED.load(Relaxed) {
            ALLOCS.fetch_add(1, Relaxed);
            REQUESTED.fetch_add(layout.size(), Relaxed);
        }
        // SAFETY: caller supplies the valid allocator layout; System returns its allocation.
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        if ENABLED.load(Relaxed) {
            ALLOCS.fetch_add(1, Relaxed);
            REQUESTED.fetch_add(layout.size(), Relaxed);
        }
        // SAFETY: identical contract to the caller's alloc_zeroed request.
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        // SAFETY: pointer/layout are forwarded to the allocator that created them.
        unsafe { System.dealloc(pointer, layout) }
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        if ENABLED.load(Relaxed) {
            REALLOCS.fetch_add(1, Relaxed);
            REQUESTED.fetch_add(new_size, Relaxed);
        }
        // SAFETY: the caller's live pointer, old layout and new size are unmodified.
        unsafe { System.realloc(pointer, layout, new_size) }
    }
}
#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

fn counted<F: FnOnce() -> Option<f64>>(name: &str, f: F) {
    ALLOCS.store(0, Relaxed);
    REALLOCS.store(0, Relaxed);
    REQUESTED.store(0, Relaxed);
    ENABLED.store(true, Relaxed);
    let result = f();
    ENABLED.store(false, Relaxed);
    println!(
        "{name}: result={result:?} alloc_calls={} realloc_calls={} total_requested_bytes={} (not peak/live bytes)",
        ALLOCS.load(Relaxed),
        REALLOCS.load(Relaxed),
        REQUESTED.load(Relaxed)
    );
}

fn main() {
    for fixture in fixtures() {
        let mut raw = fixture.edges.clone();
        raw.sort_unstable_by_key(|&(a, b, _)| (a, b));
        let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
        let edges: Vec<_> = raw
            .iter()
            .map(|&(a, b, w)| {
                (
                    fixture.labels[a as usize].as_str(),
                    fixture.labels[b as usize].as_str(),
                    w,
                )
            })
            .collect();
        let probe = grafo_probe::Graph::new(&nodes, &edges).unwrap();
        let (_, stats) = probe.probe_trace(0, (nodes.len() - 1) as u32);
        println!(
            "TRACE {} V={} E={} {stats:?}",
            fixture.name,
            nodes.len(),
            raw.len()
        );
    }
    let fixture = Fixture::sparse(100_000, 4);
    let mut raw = fixture.edges.clone();
    raw.sort_unstable_by_key(|&(a, b, _)| (a, b));
    let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
    let edges: Vec<_> = raw
        .iter()
        .map(|&(a, b, w)| {
            (
                fixture.labels[a as usize].as_str(),
                fixture.labels[b as usize].as_str(),
                w,
            )
        })
        .collect();
    let probe = grafo_probe::Graph::new(&nodes, &edges).unwrap();
    let real = grafo::Graph::new(&nodes, &edges).unwrap();
    let pet = fixture.build_petgraph();
    counted("production_grafo", || {
        real.shortest_path_cost("0", "99999").unwrap()
    });
    counted("stock_petgraph", || stock_cost(&pet, 0, 99_999));
    for policy in [
        Policy::Native,
        Policy::Reserve512,
        Policy::ZeroSentinel,
        Policy::SparseFx,
        Policy::ReuseDense,
        Policy::ReuseTouched,
        Policy::ReuseEpoch,
    ] {
        let mut scratch = Scratch::default();
        counted(&format!("{policy:?}_cold"), || {
            probe
                .probe_search("0", "99999", policy, &mut scratch)
                .unwrap()
        });
        counted(&format!("{policy:?}_warm"), || {
            probe
                .probe_search("0", "99999", policy, &mut scratch)
                .unwrap()
        });
    }
}
