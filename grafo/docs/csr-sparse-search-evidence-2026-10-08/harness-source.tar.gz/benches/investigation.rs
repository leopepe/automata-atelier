//! Diagnosis-only experiments; production grafo is unchanged.
//! Run twice with --save-baseline study1/study2; second run REVERSE_BENCH_ORDER=1.
//! Scratch variants are warmed/reused. First-call setup is NOT included in their timings.
use criterion::{Criterion, criterion_group, criterion_main};
use grafo_csr_investigation::{Fixture, fixtures, stock_cost};
use grafo_probe::{Policy, Scratch};
use std::hint::black_box;
use std::time::Duration;

fn build(
    fixture: &Fixture,
) -> (
    grafo::Graph,
    grafo_probe::Graph,
    grafo_csr_investigation::PetCsr,
) {
    let mut raw = fixture.edges.clone();
    raw.sort_unstable_by_key(|&(a, b, _)| (a, b));
    let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
    let edges: Vec<_> = raw
        .iter()
        .map(|&(a, b, w)| {
            (
                fixture.labels[a as usize].as_str(),
                fixture.labels[b as usize].as_str(),
                w,
            )
        })
        .collect();
    (
        grafo::Graph::new(&nodes, &edges).unwrap(),
        grafo_probe::Graph::new(&nodes, &edges).unwrap(),
        fixture.build_petgraph(),
    )
}

const POLICIES: [(&str, Policy); 7] = [
    ("probe_native", Policy::Native),
    ("reserve_heap512", Policy::Reserve512),
    ("zero_sentinel", Policy::ZeroSentinel),
    ("reuse_dense_fill", Policy::ReuseDense),
    ("reuse_touched", Policy::ReuseTouched),
    ("reuse_epoch", Policy::ReuseEpoch),
    ("sparse_fx_single_use", Policy::SparseFx),
];

fn study(c: &mut Criterion) {
    for fixture in fixtures() {
        let (real, probe, pet) = build(&fixture);
        let n = fixture.labels.len();
        for &(name, policy) in &POLICIES {
            let mut scratch = Scratch::default();
            for (src, dst) in [
                (0, n - 1),
                (0, n / 2),
                (n / 4, n - 1),
                (n / 2, n - 1),
                (0, 1),
                (n - 2, n - 1),
                (n - 1, 0),
                (n / 2, n / 2),
            ] {
                let expected = real
                    .shortest_path_cost(&fixture.labels[src], &fixture.labels[dst])
                    .unwrap();
                assert_eq!(
                    probe
                        .probe_search(
                            &fixture.labels[src],
                            &fixture.labels[dst],
                            policy,
                            &mut scratch
                        )
                        .unwrap(),
                    expected,
                    "{} {name} {src}->{dst}",
                    fixture.name
                );
                assert_eq!(stock_cost(&pet, src as u32, dst as u32), expected);
            }
        }
        let target = fixture.labels[n - 1].as_str();
        let mut group = c.benchmark_group(format!("variants/{}", fixture.name));
        let mut names = vec![
            "production_grafo",
            "stock_petgraph",
            "numeric_endpoint_control",
        ];
        names.extend(POLICIES.iter().map(|x| x.0));
        if std::env::var_os("REVERSE_BENCH_ORDER").is_some() {
            names.reverse();
        }
        for name in names {
            match name {
                "production_grafo" => {
                    group.bench_function(name, |b| {
                        b.iter(|| {
                            black_box(
                                real.shortest_path_cost(black_box("0"), black_box(target))
                                    .unwrap(),
                            )
                        })
                    });
                }
                "stock_petgraph" => {
                    group.bench_function(name, |b| {
                        b.iter(|| {
                            black_box(stock_cost(&pet, black_box(0), black_box((n - 1) as u32)))
                        })
                    });
                }
                "numeric_endpoint_control" => {
                    group.bench_function(name, |b| {
                        b.iter(|| {
                            black_box(
                                probe.probe_numeric_cost(black_box(0), black_box((n - 1) as u32)),
                            )
                        })
                    });
                }
                _ => {
                    let policy = POLICIES.iter().find(|x| x.0 == name).unwrap().1;
                    let mut scratch = Scratch::default();
                    assert_eq!(
                        probe
                            .probe_search("0", target, policy, &mut scratch)
                            .unwrap(),
                        real.shortest_path_cost("0", target).unwrap()
                    );
                    group.bench_function(name, |b| {
                        b.iter(|| {
                            black_box(
                                probe
                                    .probe_search(
                                        black_box("0"),
                                        black_box(target),
                                        policy,
                                        &mut scratch,
                                    )
                                    .unwrap(),
                            )
                        })
                    });
                }
            }
        }
        group.finish();
    }

    let mut component = c.benchmark_group("components");
    for n in [1_000, 10_000, 100_000, 1_000_000] {
        component.bench_function(format!("fresh_infinity_{n}"), |b| {
            b.iter(|| black_box(vec![f64::INFINITY; black_box(n)]))
        });
        component.bench_function(format!("fresh_zero_{n}"), |b| {
            b.iter(|| black_box(vec![0_u64; black_box(n)]))
        });
        component.bench_function(format!("allocate_only_{n}"), |b| {
            b.iter(|| black_box(Vec::<f64>::with_capacity(black_box(n))))
        });
        let mut dist = vec![f64::INFINITY; n];
        component.bench_function(format!("retained_fill_infinity_{n}"), |b| {
            b.iter(|| black_box(dist.as_mut_slice()).fill(black_box(f64::INFINITY)))
        });
    }
    let target_fixture = Fixture::sparse(100_000, 4);
    let (_, probe, _) = build(&target_fixture);
    component.bench_function("label_resolution_100k", |b| {
        b.iter(|| black_box(probe.probe_resolve(black_box("0"), black_box("99999"))))
    });
    component.finish();

    // Causal control: add isolated vertices without changing any reachable edges or goal.
    for n in [250_000, 1_000_000] {
        let mut fixture = Fixture::sparse(100_000, 4);
        fixture.labels.extend((100_000..n).map(|i| i.to_string()));
        let (real, probe, pet) = build(&fixture);
        let mut group = c.benchmark_group(format!("padding/same_search_vertices_{n}"));
        group.bench_function("production_grafo", |b| {
            b.iter(|| {
                black_box(
                    real.shortest_path_cost(black_box("0"), black_box("99999"))
                        .unwrap(),
                )
            })
        });
        group.bench_function("stock_petgraph", |b| {
            b.iter(|| black_box(stock_cost(&pet, black_box(0), black_box(99_999))))
        });
        for (name, policy) in [
            ("reuse_touched", Policy::ReuseTouched),
            ("reuse_epoch", Policy::ReuseEpoch),
            ("zero_sentinel", Policy::ZeroSentinel),
            ("sparse_fx_single_use", Policy::SparseFx),
        ] {
            let mut scratch = Scratch::default();
            assert_eq!(
                probe
                    .probe_search("0", "99999", policy, &mut scratch)
                    .unwrap(),
                Some(116.0)
            );
            group.bench_function(name, |b| {
                b.iter(|| {
                    black_box(
                        probe
                            .probe_search(black_box("0"), black_box("99999"), policy, &mut scratch)
                            .unwrap(),
                    )
                })
            });
        }
        group.finish();
    }
}

criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(50).warm_up_time(Duration::from_millis(500)).measurement_time(Duration::from_millis(1500));
    targets = study
}
criterion_main!(benches);
