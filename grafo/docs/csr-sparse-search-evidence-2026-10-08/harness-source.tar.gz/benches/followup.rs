//! First-call, changing-query and alternate-seed checks for candidate applicability.
use criterion::{Criterion, criterion_group, criterion_main};
use grafo_csr_investigation::{Fixture, stock_cost};
use grafo_probe::{Policy, Scratch};
use std::hint::black_box;
use std::time::Duration;

fn build(
    fixture: &Fixture,
) -> (
    grafo::Graph,
    grafo_probe::Graph,
    grafo_csr_investigation::PetCsr,
) {
    let mut raw = fixture.edges.clone();
    raw.sort_unstable_by_key(|&(a, b, _)| (a, b));
    let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
    let edges: Vec<_> = raw
        .iter()
        .map(|&(a, b, w)| {
            (
                fixture.labels[a as usize].as_str(),
                fixture.labels[b as usize].as_str(),
                w,
            )
        })
        .collect();
    (
        grafo::Graph::new(&nodes, &edges).unwrap(),
        grafo_probe::Graph::new(&nodes, &edges).unwrap(),
        fixture.build_petgraph(),
    )
}

fn followup(c: &mut Criterion) {
    let fixture = Fixture::sparse(100_000, 4);
    let (real, probe, _) = build(&fixture);
    let mut cold = c.benchmark_group("first_call");
    for count in [1, 4] {
        cold.bench_function(format!("production_{count}_queries"), |b| {
            b.iter(|| {
                for _ in 0..count {
                    black_box(
                        real.shortest_path_cost(black_box("0"), black_box("99999"))
                            .unwrap(),
                    );
                }
            })
        });
        for (name, policy) in [
            ("epoch", Policy::ReuseEpoch),
            ("touched", Policy::ReuseTouched),
        ] {
            cold.bench_function(format!("{name}_{count}_queries_with_setup"), |b| {
                b.iter(|| {
                    let mut scratch = Scratch::default();
                    for _ in 0..count {
                        black_box(
                            probe
                                .probe_search(
                                    black_box("0"),
                                    black_box("99999"),
                                    policy,
                                    &mut scratch,
                                )
                                .unwrap(),
                        );
                    }
                })
            });
        }
    }
    cold.finish();

    let queries = [
        (0, 99_999),
        (0, 50_000),
        (25_000, 99_999),
        (50_000, 99_999),
        (0, 1),
        (99_998, 99_999),
        (99_999, 0),
        (50_000, 50_000),
    ];
    let mut rotation = c.benchmark_group("rotating_8_queries");
    rotation.bench_function("production", |b| {
        b.iter(|| {
            for &(src, dst) in black_box(&queries) {
                black_box(
                    real.shortest_path_cost(&fixture.labels[src], &fixture.labels[dst])
                        .unwrap(),
                );
            }
        })
    });
    for (name, policy) in [
        ("epoch_warm", Policy::ReuseEpoch),
        ("touched_warm", Policy::ReuseTouched),
        ("sparse_fx", Policy::SparseFx),
    ] {
        let mut scratch = Scratch::default();
        for &(src, dst) in &queries {
            assert_eq!(
                probe
                    .probe_search(
                        &fixture.labels[src],
                        &fixture.labels[dst],
                        policy,
                        &mut scratch
                    )
                    .unwrap(),
                real.shortest_path_cost(&fixture.labels[src], &fixture.labels[dst])
                    .unwrap()
            );
        }
        rotation.bench_function(name, |b| {
            b.iter(|| {
                for &(src, dst) in black_box(&queries) {
                    black_box(
                        probe
                            .probe_search(
                                &fixture.labels[src],
                                &fixture.labels[dst],
                                policy,
                                &mut scratch,
                            )
                            .unwrap(),
                    );
                }
            })
        });
    }
    rotation.finish();

    for seed in [1, 42, 20_261_008] {
        let fixture = Fixture::sparse_seed(100_000, 4, seed);
        let (real, probe, pet) = build(&fixture);
        let expected = real.shortest_path_cost("0", "99999").unwrap();
        assert_eq!(stock_cost(&pet, 0, 99_999), expected);
        let (_, stats) = probe.probe_trace(0, 99_999);
        eprintln!("SEED {seed} result={expected:?} {stats:?}");
        let mut group = c.benchmark_group(format!("alternate_seed_{seed}"));
        group.bench_function("production", |b| {
            b.iter(|| {
                black_box(
                    real.shortest_path_cost(black_box("0"), black_box("99999"))
                        .unwrap(),
                )
            })
        });
        group.bench_function("petgraph", |b| {
            b.iter(|| black_box(stock_cost(&pet, black_box(0), black_box(99_999))))
        });
        for (name, policy) in [
            ("epoch_warm", Policy::ReuseEpoch),
            ("touched_warm", Policy::ReuseTouched),
            ("sparse_fx", Policy::SparseFx),
        ] {
            let mut scratch = Scratch::default();
            assert_eq!(
                probe
                    .probe_search("0", "99999", policy, &mut scratch)
                    .unwrap(),
                expected
            );
            group.bench_function(name, |b| {
                b.iter(|| {
                    black_box(
                        probe
                            .probe_search(black_box("0"), black_box("99999"), policy, &mut scratch)
                            .unwrap(),
                    )
                })
            });
        }
        group.finish();
    }
}

criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(50).warm_up_time(Duration::from_millis(500)).measurement_time(Duration::from_millis(1500));
    targets = followup
}
criterion_main!(benches);
