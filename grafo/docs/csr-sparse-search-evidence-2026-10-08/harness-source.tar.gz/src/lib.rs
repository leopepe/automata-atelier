//! Throwaway fixtures for a grafo versus petgraph CSR comparison.
use grafo::Graph;
use petgraph::Directed;
use petgraph::algo::dijkstra;
use petgraph::csr::Csr;
use petgraph::visit::EdgeRef;
use std::cmp::Reverse;
use std::collections::BinaryHeap;

pub type PetCsr = Csr<String, f64, Directed, u32>;
pub type Edge = (u32, u32, f64);

pub struct Fixture {
    pub name: String,
    pub labels: Vec<String>,
    pub edges: Vec<Edge>,
}

fn lcg(state: &mut u64) -> u64 {
    *state = state
        .wrapping_mul(6_364_136_223_846_793_005)
        .wrapping_add(1_442_695_040_888_963_407);
    *state
}

impl Fixture {
    pub fn chain(n: u32) -> Self {
        Self {
            name: format!("chain_{n}"),
            labels: (0..n).map(|i| i.to_string()).collect(),
            edges: (0..n - 1).map(|i| (i, i + 1, 1.0)).collect(),
        }
    }

    pub fn sparse(n: u32, fan: u32) -> Self {
        Self::sparse_seed(n, fan, 0xdead_beef_cafe)
    }

    pub fn sparse_seed(n: u32, fan: u32, seed: u64) -> Self {
        let mut rng = seed;
        let mut edges = Vec::new();
        for i in 0..n - 1 {
            // Backbone guarantees reachability; random forward shortcuts carry integer weights.
            edges.push((i, i + 1, 100.0));
            for _ in 0..fan {
                let target = i + 1 + (lcg(&mut rng) % u64::from(n - i - 1)) as u32;
                let weight = (lcg(&mut rng) % 100 + 1) as f64;
                edges.push((i, target, weight));
            }
        }
        edges.sort_unstable_by(|a, b| (a.0, a.1).cmp(&(b.0, b.1)).then(a.2.total_cmp(&b.2)));
        // Keep the cheapest duplicate edge; petgraph CSR forbids parallel edges.
        edges.dedup_by_key(|edge| (edge.0, edge.1));
        // Identical unsorted input for both builders. CSR must sort inside its timed build.
        edges.reverse();
        Self {
            name: format!("sparse_{n}_fan{fan}_plus_backbone"),
            labels: (0..n).map(|i| i.to_string()).collect(),
            edges,
        }
    }

    pub fn layered(layers: u32, width: u32) -> Self {
        let mut edges = Vec::new();
        let mut rng = 17;
        for layer in 0..layers - 1 {
            for source in layer * width..(layer + 1) * width {
                for target in (layer + 1) * width..(layer + 2) * width {
                    edges.push((source, target, (lcg(&mut rng) % 100 + 1) as f64));
                }
            }
        }
        edges.reverse();
        Self {
            name: format!("layered_{layers}x{width}"),
            labels: (0..layers * width).map(|i| i.to_string()).collect(),
            edges,
        }
    }

    pub fn grafo_inputs(&self) -> (Vec<&str>, Vec<(&str, &str, f64)>) {
        let nodes = self.labels.iter().map(String::as_str).collect();
        let edges = self
            .edges
            .iter()
            .map(|&(a, b, w)| {
                (
                    self.labels[a as usize].as_str(),
                    self.labels[b as usize].as_str(),
                    w,
                )
            })
            .collect();
        (nodes, edges)
    }

    pub fn build_petgraph(&self) -> PetCsr {
        // Clone is required to sort borrowed input; counted in construction timings.
        let mut edges = self.edges.clone();
        edges.sort_unstable_by_key(|&(a, b, _)| (a, b));
        let mut graph = PetCsr::from_sorted_edges(&edges).unwrap();
        while graph.node_count() < self.labels.len() {
            graph.add_node(String::new());
        }
        for (i, label) in self.labels.iter().enumerate() {
            // Each library owns the same String labels; CSR has no label lookup index.
            graph[i as u32] = label.to_owned();
        }
        graph
    }
}

pub fn stock_cost(graph: &PetCsr, source: u32, target: u32) -> Option<f64> {
    dijkstra(graph, source, Some(target), |edge| *edge.weight())
        .get(&target)
        .copied()
}

/// Control: grafo's vector-distance/heap strategy over petgraph CSR storage.
/// Uses numeric endpoints (no string lookup) and performs no attribute filtering.
/// This is NOT petgraph's stock Dijkstra implementation.
pub fn matched_cost(graph: &PetCsr, source: u32, target: u32) -> Option<f64> {
    let mut dist = vec![f64::INFINITY; graph.node_count()];
    dist[source as usize] = 0.0;
    let mut heap = BinaryHeap::new();
    heap.push((Reverse(0_u64), source));
    while let Some((Reverse(bits), node)) = heap.pop() {
        let cost = f64::from_bits(bits);
        if cost > dist[node as usize] {
            continue;
        }
        if node == target {
            return Some(cost);
        }
        for edge in graph.edges(node) {
            let next = edge.target();
            let new_cost = cost + edge.weight();
            if new_cost < dist[next as usize] {
                dist[next as usize] = new_cost;
                heap.push((Reverse(new_cost.to_bits()), next));
            }
        }
    }
    None
}

pub fn fixtures() -> Vec<Fixture> {
    vec![
        Fixture::chain(10_000),
        Fixture::chain(100_000),
        Fixture::sparse(10_000, 4),
        Fixture::sparse(100_000, 4),
        Fixture::sparse(10_000, 16),
        Fixture::layered(100, 30),
    ]
}

pub fn verify(fixture: &Fixture, grafo: &Graph, pet: &PetCsr) {
    let n = fixture.labels.len() as u32;
    assert_eq!(pet.node_count(), fixture.labels.len());
    assert_eq!(pet.edge_count(), fixture.edges.len());
    for (source, target) in [
        (0, n - 1),
        (0, n / 2),
        (n / 4, n - 1),
        (n / 2, n - 1),
        (0, 1),
        (n - 2, n - 1),
        (n - 1, 0),
        (n / 2, n / 2),
    ] {
        let actual = grafo
            .shortest_path_cost(
                &fixture.labels[source as usize],
                &fixture.labels[target as usize],
            )
            .unwrap();
        assert_eq!(
            actual,
            stock_cost(pet, source, target),
            "{} stock {source}->{target}",
            fixture.name
        );
        assert_eq!(
            actual,
            matched_cost(pet, source, target),
            "{} matched {source}->{target}",
            fixture.name
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn probe_variants_match_all_pairs_on_fractional_zero_weight_reordered_dags() {
        use grafo_probe::{Policy, Scratch};
        for seed in [1, 2, 17, 42, 99, 20_261_008] {
            let fixture = Fixture::sparse_seed(16, 4, seed);
            let nodes: Vec<_> = fixture.labels.iter().map(String::as_str).collect();
            let edges: Vec<_> = fixture
                .edges
                .iter()
                .enumerate()
                .map(|(i, &(a, b, weight))| {
                    // Reverse IDs without reversing graph direction: numerical order is not topology.
                    let weight = if i % 7 == 0 { 0.0 } else { weight * 0.25 };
                    (
                        fixture.labels[(15 - a) as usize].as_str(),
                        fixture.labels[(15 - b) as usize].as_str(),
                        weight,
                    )
                })
                .collect();
            let real = Graph::new(&nodes, &edges).unwrap();
            let probe = grafo_probe::Graph::new(&nodes, &edges).unwrap();
            for policy in [
                Policy::Native,
                Policy::Reserve512,
                Policy::ZeroSentinel,
                Policy::ReuseDense,
                Policy::ReuseTouched,
                Policy::ReuseEpoch,
                Policy::SparseFx,
            ] {
                let mut scratch = Scratch::default();
                for source in 0..16 {
                    for target in 0..16 {
                        assert_eq!(
                            probe
                                .probe_search(
                                    &fixture.labels[source],
                                    &fixture.labels[target],
                                    policy,
                                    &mut scratch
                                )
                                .unwrap(),
                            real.shortest_path_cost(
                                &fixture.labels[source],
                                &fixture.labels[target]
                            )
                            .unwrap(),
                            "seed={seed} policy={policy:?} {source}->{target}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn known_cost_and_unreachable_match() {
        let fixture = Fixture {
            name: "known".into(),
            labels: vec!["a".into(), "b".into(), "c".into(), "isolated".into()],
            edges: vec![(1, 2, 2.0), (0, 2, 9.0), (0, 1, 1.0)],
        };
        let (nodes, edges) = fixture.grafo_inputs();
        let grafo = Graph::new(&nodes, &edges).unwrap();
        let pet = fixture.build_petgraph();
        for (source, target, expected) in [
            (0, 2, Some(3.0)),
            (0, 3, None),
            (3, 3, Some(0.0)),
            (2, 0, None),
        ] {
            assert_eq!(
                grafo
                    .shortest_path_cost(
                        &fixture.labels[source as usize],
                        &fixture.labels[target as usize]
                    )
                    .unwrap(),
                expected
            );
            assert_eq!(stock_cost(&pet, source, target), expected);
            assert_eq!(matched_cost(&pet, source, target), expected);
        }
    }

    #[test]
    fn all_measured_fixtures_agree() {
        for fixture in fixtures() {
            let (nodes, edges) = fixture.grafo_inputs();
            let grafo = Graph::new(&nodes, &edges).unwrap();
            let pet = fixture.build_petgraph();
            verify(&fixture, &grafo, &pet);
            println!(
                "verified {}: {} nodes, {} edges, 8 queries",
                fixture.name,
                pet.node_count(),
                pet.edge_count()
            );
        }
    }
}
