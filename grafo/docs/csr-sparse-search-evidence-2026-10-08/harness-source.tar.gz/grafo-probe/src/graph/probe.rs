//! Throwaway search variants over the actual grafo CSR fields; not a production API.
use super::{Graph, GraphError};
use rustc_hash::FxHashMap;
use std::cmp::Reverse;
use std::collections::BinaryHeap;

type Heap = BinaryHeap<(Reverse<u64>, u32)>;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Policy {
    Native,
    Reserve512,
    ZeroSentinel,
    ReuseDense,
    ReuseTouched,
    ReuseEpoch,
    SparseFx,
}

#[derive(Default)]
pub struct Scratch {
    dist: Vec<f64>,
    stamps: Vec<u32>,
    touched: Vec<u32>,
    heap: Heap,
    pub epoch: u32,
    last_policy: Option<Policy>,
}

impl Scratch {
    fn prepare(&mut self, n: usize, policy: Policy) {
        if self.dist.len() != n || self.last_policy != Some(policy) {
            self.dist = vec![f64::INFINITY; n];
            self.stamps.clear();
            if policy == Policy::ReuseEpoch {
                self.stamps.resize(n, 0);
            }
            self.touched.clear();
            self.epoch = 0;
            self.last_policy = Some(policy);
        }
        self.heap.clear();
    }
}

#[derive(Default, Debug)]
pub struct SearchStats {
    pub pops: usize,
    pub stale_pops: usize,
    pub expanded: usize,
    pub edges: usize,
    pub relaxations: usize,
    pub discovered: usize,
    pub pushes: usize,
    pub peak_heap: usize,
}

impl Graph {
    pub fn probe_search(
        &self,
        from: &str,
        to: &str,
        policy: Policy,
        scratch: &mut Scratch,
    ) -> Result<Option<f64>, GraphError> {
        let src = *self
            .node_index
            .get(from)
            .ok_or_else(|| GraphError::UnknownNode(from.to_owned()))?;
        let dst = *self
            .node_index
            .get(to)
            .ok_or_else(|| GraphError::UnknownNode(to.to_owned()))?;
        if src == dst {
            return Ok(Some(0.0));
        }
        Ok(match policy {
            Policy::Native => self.dijkstra_cost(src, dst, &|_| true),
            Policy::Reserve512 => {
                let mut dist = vec![f64::INFINITY; self.node_ids.len()];
                let mut heap = Heap::with_capacity(512);
                self.probe_dense_loop(src, dst, &mut dist, &mut heap)
            }
            Policy::ZeroSentinel => self.probe_zero(src, dst),
            Policy::SparseFx => self.probe_sparse(src, dst),
            Policy::ReuseDense => {
                scratch.prepare(self.node_ids.len(), policy);
                scratch.dist.fill(f64::INFINITY);
                self.probe_dense_loop(src, dst, &mut scratch.dist, &mut scratch.heap)
            }
            Policy::ReuseTouched => {
                scratch.prepare(self.node_ids.len(), policy);
                for node in scratch.touched.drain(..) {
                    scratch.dist[node as usize] = f64::INFINITY;
                }
                scratch.dist[src as usize] = 0.0;
                scratch.touched.push(src);
                scratch.heap.push((Reverse(0), src));
                while let Some((Reverse(bits), node)) = scratch.heap.pop() {
                    let cost = f64::from_bits(bits);
                    if cost > scratch.dist[node as usize] {
                        continue;
                    }
                    if node == dst {
                        return Ok(Some(cost));
                    }
                    for i in self.offsets[node as usize] as usize
                        ..self.offsets[node as usize + 1] as usize
                    {
                        let next = self.targets[i] as usize;
                        let new_cost = cost + self.weights[i];
                        if new_cost < scratch.dist[next] {
                            if scratch.dist[next].is_infinite() {
                                scratch.touched.push(next as u32);
                            }
                            scratch.dist[next] = new_cost;
                            scratch
                                .heap
                                .push((Reverse(new_cost.to_bits()), next as u32));
                        }
                    }
                }
                None
            }
            Policy::ReuseEpoch => {
                scratch.prepare(self.node_ids.len(), policy);
                scratch.epoch = scratch.epoch.wrapping_add(1);
                if scratch.epoch == 0 {
                    // Clear historical generations on overflow; zero is reserved for unseen.
                    scratch.stamps.fill(0);
                    scratch.epoch = 1;
                }
                let epoch = scratch.epoch;
                scratch.dist[src as usize] = 0.0;
                scratch.stamps[src as usize] = epoch;
                scratch.heap.push((Reverse(0), src));
                while let Some((Reverse(bits), node)) = scratch.heap.pop() {
                    let cost = f64::from_bits(bits);
                    if cost > scratch.dist[node as usize] {
                        continue;
                    }
                    if node == dst {
                        return Ok(Some(cost));
                    }
                    for i in self.offsets[node as usize] as usize
                        ..self.offsets[node as usize + 1] as usize
                    {
                        let next = self.targets[i] as usize;
                        let new_cost = cost + self.weights[i];
                        if scratch.stamps[next] != epoch || new_cost < scratch.dist[next] {
                            scratch.stamps[next] = epoch;
                            scratch.dist[next] = new_cost;
                            scratch
                                .heap
                                .push((Reverse(new_cost.to_bits()), next as u32));
                        }
                    }
                }
                None
            }
        })
    }

    pub fn probe_numeric_cost(&self, src: u32, dst: u32) -> Option<f64> {
        if src == dst {
            return Some(0.0);
        }
        self.dijkstra_cost(src, dst, &|_| true)
    }

    pub fn probe_resolve(&self, from: &str, to: &str) -> Option<(u32, u32)> {
        Some((*self.node_index.get(from)?, *self.node_index.get(to)?))
    }

    #[inline]
    fn probe_dense_loop(
        &self,
        src: u32,
        dst: u32,
        dist: &mut [f64],
        heap: &mut Heap,
    ) -> Option<f64> {
        dist[src as usize] = 0.0;
        heap.push((Reverse(0), src));
        while let Some((Reverse(bits), node)) = heap.pop() {
            let cost = f64::from_bits(bits);
            if cost > dist[node as usize] {
                continue;
            }
            if node == dst {
                return Some(cost);
            }
            for i in self.offsets[node as usize] as usize..self.offsets[node as usize + 1] as usize
            {
                let next = self.targets[i] as usize;
                let new_cost = cost + self.weights[i];
                if new_cost < dist[next] {
                    dist[next] = new_cost;
                    heap.push((Reverse(new_cost.to_bits()), next as u32));
                }
            }
        }
        None
    }

    fn probe_zero(&self, src: u32, dst: u32) -> Option<f64> {
        // Sentinel 0 means unseen; finite non-negative distance bits are encoded +1.
        let mut dist = vec![0_u64; self.node_ids.len()];
        let mut heap = Heap::new();
        dist[src as usize] = 1;
        heap.push((Reverse(0), src));
        while let Some((Reverse(bits), node)) = heap.pop() {
            if bits > dist[node as usize] - 1 {
                continue;
            }
            let cost = f64::from_bits(bits);
            if node == dst {
                return Some(cost);
            }
            for i in self.offsets[node as usize] as usize..self.offsets[node as usize + 1] as usize
            {
                let next = self.targets[i] as usize;
                let next_bits = (cost + self.weights[i]).to_bits();
                let old_bits = if dist[next] == 0 {
                    f64::INFINITY.to_bits()
                } else {
                    dist[next] - 1
                };
                if next_bits < old_bits {
                    dist[next] = next_bits + 1;
                    heap.push((Reverse(next_bits), next as u32));
                }
            }
        }
        None
    }

    fn probe_sparse(&self, src: u32, dst: u32) -> Option<f64> {
        let mut dist = FxHashMap::default();
        let mut heap = Heap::new();
        dist.insert(src, 0.0);
        heap.push((Reverse(0), src));
        while let Some((Reverse(bits), node)) = heap.pop() {
            let cost = f64::from_bits(bits);
            if cost > dist[&node] {
                continue;
            }
            if node == dst {
                return Some(cost);
            }
            for i in self.offsets[node as usize] as usize..self.offsets[node as usize + 1] as usize
            {
                let next = self.targets[i];
                let new_cost = cost + self.weights[i];
                let current = dist.entry(next).or_insert(f64::INFINITY);
                if new_cost < *current {
                    *current = new_cost;
                    heap.push((Reverse(new_cost.to_bits()), next));
                }
            }
        }
        None
    }

    pub fn probe_trace(&self, src: u32, dst: u32) -> (Option<f64>, SearchStats) {
        let mut stats = SearchStats {
            discovered: 1,
            pushes: 1,
            peak_heap: 1,
            ..Default::default()
        };
        let mut dist = vec![f64::INFINITY; self.node_ids.len()];
        let mut heap = Heap::new();
        dist[src as usize] = 0.0;
        heap.push((Reverse(0), src));
        while let Some((Reverse(bits), node)) = heap.pop() {
            stats.pops += 1;
            let cost = f64::from_bits(bits);
            if cost > dist[node as usize] {
                stats.stale_pops += 1;
                continue;
            }
            if node == dst {
                return (Some(cost), stats);
            }
            stats.expanded += 1;
            for i in self.offsets[node as usize] as usize..self.offsets[node as usize + 1] as usize
            {
                stats.edges += 1;
                let next = self.targets[i] as usize;
                let new_cost = cost + self.weights[i];
                if new_cost < dist[next] {
                    if dist[next].is_infinite() {
                        stats.discovered += 1;
                    }
                    stats.relaxations += 1;
                    dist[next] = new_cost;
                    heap.push((Reverse(new_cost.to_bits()), next as u32));
                    stats.pushes += 1;
                    stats.peak_heap = stats.peak_heap.max(heap.len());
                }
            }
        }
        (None, stats)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn graph() -> Graph {
        Graph::new(
            &["a", "b", "c", "z"],
            &[("a", "b", 1.0), ("a", "c", 9.0), ("b", "c", 2.0)],
        )
        .unwrap()
    }
    #[test]
    fn variants_match_costs_across_reused_queries() {
        let graph = graph();
        for policy in [
            Policy::Native,
            Policy::Reserve512,
            Policy::ZeroSentinel,
            Policy::ReuseDense,
            Policy::ReuseTouched,
            Policy::ReuseEpoch,
            Policy::SparseFx,
        ] {
            let mut scratch = Scratch::default();
            for (src, dst, expected) in [
                ("a", "c", Some(3.0)),
                ("b", "c", Some(2.0)),
                ("c", "a", None),
                ("a", "z", None),
                ("a", "c", Some(3.0)),
                ("z", "z", Some(0.0)),
            ] {
                assert_eq!(
                    graph.probe_search(src, dst, policy, &mut scratch).unwrap(),
                    expected,
                    "{policy:?} {src}->{dst}"
                );
            }
        }
    }
    #[test]
    fn epoch_overflow_invalidates_old_distances() {
        let graph = graph();
        let mut scratch = Scratch::default();
        assert_eq!(
            graph
                .probe_search("a", "c", Policy::ReuseEpoch, &mut scratch)
                .unwrap(),
            Some(3.0)
        );
        scratch.epoch = u32::MAX;
        assert_eq!(
            graph
                .probe_search("b", "c", Policy::ReuseEpoch, &mut scratch)
                .unwrap(),
            Some(2.0)
        );
        assert_eq!(scratch.epoch, 1);
    }
    #[test]
    fn scratch_handles_graph_size_and_policy_changes() {
        let first = graph();
        let second = Graph::new(&["a", "b", "c", "d", "z"], &[("a", "c", 7.0)]).unwrap();
        let same_size = Graph::new(&["a", "b", "c", "z"], &[("a", "c", 12.0)]).unwrap();
        let mut scratch = Scratch::default();
        for policy in [
            Policy::ReuseTouched,
            Policy::ReuseEpoch,
            Policy::ReuseDense,
            Policy::ReuseTouched,
        ] {
            assert_eq!(
                first.probe_search("a", "c", policy, &mut scratch).unwrap(),
                Some(3.0)
            );
            assert_eq!(
                same_size
                    .probe_search("a", "c", policy, &mut scratch)
                    .unwrap(),
                Some(12.0)
            );
            assert_eq!(
                second.probe_search("a", "c", policy, &mut scratch).unwrap(),
                Some(7.0)
            );
        }
    }
    #[test]
    fn zero_sentinel_preserves_zero_and_overflow_costs() {
        let graph = Graph::new(
            &["a", "b", "c", "d"],
            &[
                ("a", "b", -0.0),
                ("b", "c", 0.0),
                ("a", "d", 1.0e308),
                ("d", "c", 1.0e308),
            ],
        )
        .unwrap();
        let overflow = Graph::new(
            &["a", "b", "c"],
            &[("a", "b", 1.0e308), ("b", "c", 1.0e308)],
        )
        .unwrap();
        let mut scratch = Scratch::default();
        assert_eq!(
            graph
                .probe_search("a", "c", Policy::ZeroSentinel, &mut scratch)
                .unwrap(),
            Some(0.0)
        );
        assert_eq!(
            overflow
                .probe_search("a", "c", Policy::ZeroSentinel, &mut scratch)
                .unwrap(),
            None
        );
    }
    #[test]
    fn variants_discard_stale_entries_and_preserve_errors() {
        let graph = Graph::new(
            &["a", "b", "c", "z"],
            &[("a", "b", 10.0), ("a", "c", 1.0), ("c", "b", 1.0)],
        )
        .unwrap();
        let (_, stats) = graph.probe_trace(0, 3);
        assert!(stats.stale_pops > 0);
        for policy in [
            Policy::Native,
            Policy::Reserve512,
            Policy::ZeroSentinel,
            Policy::ReuseDense,
            Policy::ReuseTouched,
            Policy::ReuseEpoch,
            Policy::SparseFx,
        ] {
            let mut scratch = Scratch::default();
            assert_eq!(
                graph.probe_search("a", "b", policy, &mut scratch).unwrap(),
                Some(2.0)
            );
            assert_eq!(
                graph.probe_search("a", "z", policy, &mut scratch).unwrap(),
                None
            );
            assert!(matches!(
                graph.probe_search("unknown", "b", policy, &mut scratch),
                Err(GraphError::UnknownNode(_))
            ));
        }
    }
}
